const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();

const db = getFirestore();

// Singurul cont cu drept de administrare. Verificarea se face pe server.
const ADMIN_EMAIL = "bespalicoa@gmail.com";

function requireAdmin(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Trebuie să te autentifici.");
  }

  const email = String(request.auth.token.email || "").toLowerCase();

  if (email !== ADMIN_EMAIL || request.auth.token.email_verified !== true) {
    throw new HttpsError(
      "permission-denied",
      "Acces permis numai administratorului verificat."
    );
  }
}

const ALLOWED_ACTIONS = [
  "Conectare",
  "Deconectare",
  "A creat o clasă",
  "A șters o clasă",
  "A modificat o clasă",
  "A adăugat un elev",
  "A șters un elev",
  "A modificat un punctaj",
  "A modificat o evaluare",
  "A modificat setările"
];

function toIso(value) {
  return value?.toDate?.()?.toISOString?.() || null;
}

// Păstrăm doar detalii mici și sigure (fără nume de elevi).
function cleanDetails(raw) {
  const out = {};
  if (raw && typeof raw === "object") {
    if (typeof raw.className === "string") {
      out.className = raw.className.slice(0, 80);
    }
    if (Number.isInteger(raw.delta) && Math.abs(raw.delta) <= 100000) {
      out.delta = raw.delta;
    }
    if (typeof raw.device === "string") {
      out.device = raw.device.slice(0, 120);
    }
  }
  return out;
}

// Înregistrarea activităților utilizatorilor (apelată din aplicație).
exports.recordActivity = onCall(async request => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Autentificare necesară.");
  }

  const uid = request.auth.uid;
  const email = request.auth.token.email || "";
  const action = String(request.data?.action || "");

  if (!ALLOWED_ACTIONS.includes(action)) {
    throw new HttpsError("invalid-argument", "Acțiune nepermisă.");
  }

  const details = cleanDetails(request.data?.details);
  const profile = db.collection("atlasProfiles").doc(uid);
  const event = profile.collection("activity").doc();
  const feed = db.collection("atlasActivity").doc(event.id);
  const now = FieldValue.serverTimestamp();

  const result = await db.runTransaction(async transaction => {
    const snap = await transaction.get(profile);
    const prev = snap.exists ? snap.data() : {};
    const prevMs = prev.lastActiveAt?.toMillis?.() || 0;

    // Limită simplă: aceeași acțiune nu se scrie de mai multe ori pe secundă.
    if (prev.lastActivity === action && Date.now() - prevMs < 1000) {
      return { throttled: true };
    }

    transaction.set(
      profile,
      { uid, email, lastActiveAt: now, lastActivity: action },
      { merge: true }
    );
    transaction.set(event, { uid, email, action, details, createdAt: now });
    transaction.set(feed, { uid, email, action, details, createdAt: now });
    return { success: true };
  });

  return result;
});

// Lista conturilor din Firebase Authentication + ultima activitate.
exports.adminListUsers = onCall(async request => {
  requireAdmin(request);

  const users = [];
  let pageToken;

  do {
    const page = await getAuth().listUsers(1000, pageToken);
    pageToken = page.pageToken;

    const refs = page.users.map(u => db.collection("atlasProfiles").doc(u.uid));
    const snaps = refs.length ? await db.getAll(...refs) : [];

    page.users.forEach((user, i) => {
      const data = snaps[i].exists ? snaps[i].data() : {};
      users.push({
        uid: user.uid,
        email: user.email || "",
        displayName: user.displayName || "",
        disabled: user.disabled,
        emailVerified: user.emailVerified,
        isAdmin: (user.email || "").toLowerCase() === ADMIN_EMAIL,
        createdAt: user.metadata.creationTime || null,
        lastSignInAt: user.metadata.lastSignInTime || null,
        lastActiveAt: toIso(data.lastActiveAt),
        lastActivity: data.lastActivity || ""
      });
    });
  } while (pageToken);

  return { users };
});

// Istoricul activității unui utilizator.
exports.adminGetActivity = onCall(async request => {
  requireAdmin(request);

  const uid = String(request.data?.uid || "");

  if (!uid || uid.length > 150) {
    throw new HttpsError("invalid-argument", "Identificator invalid.");
  }

  const snapshot = await db
    .collection("atlasProfiles")
    .doc(uid)
    .collection("activity")
    .orderBy("createdAt", "desc")
    .limit(200)
    .get();

  const events = snapshot.docs.map(doc => {
    const data = doc.data();
    return {
      action: data.action || "",
      details: data.details || {},
      createdAt: toIso(data.createdAt)
    };
  });

  return { events };
});

// Activitatea recentă a tuturor utilizatorilor.
exports.adminGetRecentActivity = onCall(async request => {
  requireAdmin(request);

  const [snapshot, count] = await Promise.all([
    db.collection("atlasActivity").orderBy("createdAt", "desc").limit(100).get(),
    db.collection("atlasActivity").count().get()
  ]);

  const events = snapshot.docs.map(doc => {
    const data = doc.data();
    return {
      uid: data.uid || "",
      email: data.email || "",
      action: data.action || "",
      details: data.details || {},
      createdAt: toIso(data.createdAt)
    };
  });

  return { events, total: count.data().count };
});

// Dezactivarea / reactivarea unui cont (și deconectarea lui de pe toate dispozitivele).
exports.adminSetUserDisabled = onCall(async request => {
  requireAdmin(request);

  const uid = String(request.data?.uid || "");
  const disabled = request.data?.disabled === true;

  if (!uid || uid.length > 150) {
    throw new HttpsError("invalid-argument", "Identificator invalid.");
  }

  const target = await getAuth().getUser(uid).catch(() => null);
  if (!target) {
    throw new HttpsError("not-found", "Contul nu există.");
  }

  if ((target.email || "").toLowerCase() === ADMIN_EMAIL) {
    throw new HttpsError(
      "failed-precondition",
      "Contul de administrator nu poate fi dezactivat."
    );
  }

  await getAuth().updateUser(uid, { disabled });

  if (disabled) {
    await getAuth().revokeRefreshTokens(uid);
  }

  return { success: true, disabled };
});

// Generarea unui link pentru resetarea parolei.
exports.adminCreatePasswordResetLink = onCall(async request => {
  requireAdmin(request);

  const email = String(request.data?.email || "").trim().toLowerCase();

  if (!email) {
    throw new HttpsError("invalid-argument", "Adresa de e-mail este obligatorie.");
  }

  try {
    const link = await getAuth().generatePasswordResetLink(email, {
      url: "https://atlas-chi-bice.vercel.app/"
    });
    return { link };
  } catch (error) {
    throw new HttpsError("internal", "Nu s-a putut genera linkul de resetare.");
  }
});
