# ATLAS – cont de administrator

Administrator: bespalicoa@gmail.com (verificat pe server, în `function/index.js`).

## Instalare (o singură dată)
1. Instalează Node.js LTS (nodejs.org).
2. Terminal: `npm install -g firebase-tools` apoi `firebase login`.
3. Firebase Console (proiect atlas-f1dfd):
   - Authentication → Sign-in method: activează Google (și Email/Password).
   - Authentication → Settings → Authorized domains: adaugă `atlas-chi-bice.vercel.app`.
   - Firestore Database: Create database.
   - Plan Blaze (necesar pentru Functions).
4. În folderul `function`: `npm install`.
5. În folderul ATLAS-main: `firebase deploy --only functions,firestore:rules --project atlas-f1dfd`
6. Încarcă `index.html` și `admin.html` pe Vercel.
7. Deschide `/admin.html` → „Continuă cu Google” cu contul de administrator.

## Ce vezi în panou
- lista conturilor, data înregistrării, ultima conectare, ultima activitate;
- activitatea recentă a tuturor utilizatorilor și istoricul fiecărui utilizator;
- dezactivare / reactivare cont (utilizatorul este deconectat imediat);
- link de resetare a parolei.

## Ce se înregistrează
Conectare, deconectare, clase create/șterse/modificate, elevi adăugați/șterși,
modificări de puncte, evaluări și setări. Se păstrează doar numele clasei și o
variație numerică; NU se trimit numele elevilor.
